package com.example.ecommerce.domain.catalog;
/*
    상품 ID,상품 명 구분
 */
public enum ProductSearchType {
    PRODUCT_ID, // 상품 ID
    PRODUCT_NAME; //상품명
}
