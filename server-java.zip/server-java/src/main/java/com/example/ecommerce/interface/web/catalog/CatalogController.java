//상품 목록 조회 API
// 상품 상세 조회 API
// 최근 3일 인기상품 조회 API (필요 시 RankingService 연계 가능)